import {
  require_react
} from "./chunk-GKA3S742.js";
export default require_react();
