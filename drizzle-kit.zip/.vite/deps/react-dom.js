import {
  require_react_dom
} from "./chunk-PTKZBAVD.js";
import "./chunk-GKA3S742.js";
export default require_react_dom();
